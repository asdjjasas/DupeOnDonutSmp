# massdm-selfbot
A new way of dming everyone in alot of servers and everyone on your friends list

which gives you an effect of what other side's of discord really do feel like and not only the bright side

We are going to work on new ddos tools for ddosing people so go ahead and follow my profile for now..


|| cjj xxjddos dont get hacked kids ||
